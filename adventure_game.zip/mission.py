from collections import deque

class Mission:
    def __init__(self, description: str) -> None:
        self.description = description
        self.completed = False

    def complete(self) -> None:
        self.completed = True
        
# ===================================================================
# New code for Lab_09, PART 2
# Implement a mission queue to manage current, completed, and pending missions.
# ===================================================================
class MissionQueue:
    def __init__(self, missions: list[Mission] = []) -> None:
        self.missions: deque[Mission] = deque(missions)
        self.completed_missions: list[Mission] = []

    def add_mission(self, mission: str) -> None:
        pass

    def complete_current_mission(self) -> None:
        pass
        
    def show_current_mission(self) -> None:
        pass

    def show_completed_missions(self) -> None:
        pass

    def show_pending_missions(self) -> None:
        pass
# ===================================================================